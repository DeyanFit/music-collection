const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');
const fs = require('fs');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

// Set path to FFmpeg binary
ffmpeg.setFfmpegPath(ffmpegStatic);

exports.handler = async (event) => {
  // Assuming the input MP3 is stored in S3, retrieve it
  const bucket = event.Records[0].s3.bucket.name;
  const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
  const params = {
    Bucket: bucket,
    Key: key
  };

  try {
    const inputData = await s3.getObject(params).promise();

    // Write the MP3 file to the /tmp directory (since AWS Lambda allows use of this space)
    const inputFilePath = '/tmp/input.mp3';
    fs.writeFileSync(inputFilePath, inputData.Body);

    const outputFilePath = '/tmp/output.mp3';

    // Return a promise that handles the FFmpeg processing
    return new Promise((resolve, reject) => {
      ffmpeg(inputFilePath)
        .audioCodec('libmp3lame') // Use MP3 codec
        .toFormat('mp3')
        .outputOptions('-t', '5') // Duration set to 5 seconds
        .on('end', () => {
          console.log('Audio processing completed.');
          // Read the output file
          const outputData = fs.readFileSync(outputFilePath);

          // Save the output file back to S3
          const outputParams = {
            Bucket: bucket,
            Key: `samples/${key.split('/').pop()}`,
            Body: outputData
          };
          s3.putObject(outputParams, function(err, data) {
            if (err) {
              console.error('Error uploading:', err);
              reject(err);
            } else {
              console.log('Upload successful:', data);
              resolve('Audio processing and upload completed.');
            }
          });
        })
        .on('error', (err) => {
          console.error('Error processing audio:', err);
          reject(new Error('Error processing audio'));
        })
        .save(outputFilePath);
    });
  } catch (err) {
    console.error('Error getting object from S3:', err);
    throw new Error('Error getting object from S3');
  }
};

